/* ============================================================
   Women's Hub — Firebase Bootstrap
   ------------------------------------------------------------
   Loaded automatically by app.js. Injects firebase-config.js +
   firebase-sync.js into every page so no HTML edits are needed.
   ============================================================ */
(function () {
  // Resolve correct relative path whether we are on / or /pages/ or /admin/
  const here = location.pathname.replace(/[^/]+$/, "");
  const base =
    here.includes("/admin/") || here.includes("/pages/") ? "../js/" : "js/";

  function add(src) {
    const s = document.createElement("script");
    s.src = src;
    document.head.appendChild(s);
    return new Promise(r => (s.onload = r));
  }

  (async () => {
    await add(base + "firebase-config.js");
    await add(base + "firebase-sync.js");

    // Re-render pages when Firestore pushes updates
    window.addEventListener("wh:products-updated", () => {
      ["bestsellerGrid", "trendingGrid", "shopGrid", "productsTBody"]
        .forEach(id => {
          // Trigger a soft refresh by re-dispatching DOMContentLoaded handlers
          // if the page exposes a refresh hook.
        });
      if (window.Admin && typeof Admin.render === "function") Admin.render();
      if (window.Shop && typeof Shop.render === "function") Shop.render();
      // Generic homepage refresh
      if (typeof window.renderHomeProducts === "function") window.renderHomeProducts();
    });
  })();
})();
