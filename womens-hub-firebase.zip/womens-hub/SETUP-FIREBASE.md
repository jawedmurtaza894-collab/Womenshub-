# Women's Hub — Firebase Setup Guide

Your site has been upgraded with a **real Firebase backend** while keeping the existing luxury design 100% intact.

What was added:
- `js/firebase-config.js` — paste your Firebase config here (one file, one time)
- `js/firebase-sync.js` — real-time Firestore sync + Storage uploads + Auth helpers
- `js/firebase-bootstrap.js` — auto-loads Firebase on every page (no HTML edits needed)
- Admin panel now uses **Firebase Auth** (login overlay), **Firestore** (products) and **Firebase Storage** (image uploads)
- Products created in admin appear on the public site **instantly** via Firestore `onSnapshot`

The site still works offline (localStorage fallback) until you configure Firebase.

---

## 1. Create a Firebase project (5 min)

1. Go to <https://console.firebase.google.com> → **Add project** → name it `womens-hub` → continue (Analytics optional).
2. In the project, click the **Web icon `</>`** → register app "Women's Hub" → **copy the config object**.
3. In the left sidebar enable:
   - **Build → Authentication → Get started → Email/Password → Enable**
   - **Build → Firestore Database → Create database** → Start in **production mode** → pick a region.
   - **Build → Storage → Get started** → Start in production mode → same region.

## 2. Paste your config

Open **`js/firebase-config.js`** and replace the placeholders with the values you copied:

```js
window.WH_FIREBASE_CONFIG = {
  apiKey:            "AIzaSy...",
  authDomain:        "womens-hub.firebaseapp.com",
  projectId:         "womens-hub",
  storageBucket:     "womens-hub.appspot.com",
  messagingSenderId: "1234567890",
  appId:             "1:1234567890:web:abc123"
};
window.WH_ADMIN_EMAIL = "admin@womenshub.com"; // only this email can sign into /admin/
```

## 3. Create the admin user

Firebase Console → **Authentication → Users → Add user** → enter the email + a strong password.
This is the only account allowed into the admin panel.

## 4. Security rules (copy-paste)

**Firestore** (Console → Firestore → Rules):
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /products/{id} {
      allow read: if true;
      allow write: if request.auth != null
                   && request.auth.token.email == "admin@womenshub.com";
    }
    match /{path=**} {
      allow read, write: if request.auth != null
                         && request.auth.token.email == "admin@womenshub.com";
    }
  }
}
```

**Storage** (Console → Storage → Rules):
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /products/{file=**} {
      allow read: if true;
      allow write: if request.auth != null
                   && request.auth.token.email == "admin@womenshub.com";
    }
  }
}
```
(Change the email to match `WH_ADMIN_EMAIL`.)

Click **Publish** on both.

---

## 5. Add your first product

1. Open `admin/index.html` in your browser (locally or after deployment).
2. The admin login overlay appears → sign in with the email/password you created.
3. Go to **Products → Add Product**, fill in the fields, **upload an image file** (or paste a URL), Save.
4. Open `index.html` in another tab — the product appears in real time. No reload needed on the admin side either.

To edit/delete: hit the ✎ or 🗑 icons in the products table.

---

## 6. Deploy

**Option A — Firebase Hosting (recommended, free):**
```bash
npm install -g firebase-tools
firebase login
cd womens-hub
firebase init hosting        # public dir: . (current folder), single-page: No
firebase deploy
```

**Option B — Netlify / Vercel / GitHub Pages:** drag-and-drop the `womens-hub/` folder. It's a pure static site, no build step.

**Option C — Any web host:** upload the whole folder via FTP. Done.

After deploy, add your hosting domain in Firebase Console → **Authentication → Settings → Authorized domains**, otherwise login will fail in production.

---

## Folder structure

```
womens-hub/
├── index.html                ← homepage
├── admin/
│   └── index.html            ← admin dashboard (Firebase-protected)
├── pages/                    ← shop, product, cart, checkout, etc.
├── css/
│   ├── style.css
│   └── admin.css
├── js/
│   ├── app.js                ← core state + bootstraps Firebase
│   ├── components.js         ← header/footer/drawer
│   ├── admin.js              ← admin dashboard logic
│   ├── firebase-config.js    ← ⚙️  EDIT THIS
│   ├── firebase-sync.js      ← real-time Firestore + Storage + Auth
│   └── firebase-bootstrap.js ← auto-loader
├── data/
│   └── products.js           ← sample products (used until Firestore has data)
├── sitemap.xml
└── robots.txt
```

## How the data flow works

```
Admin uploads product
   └─► WH.fb.uploadImage(file)        → Firebase Storage URL
       WH.fb.saveProduct({...,images})→ Firestore "products" collection
                                          │
                                          ▼
                Firestore onSnapshot fires on EVERY connected device
                                          │
                                          ▼
           WH.state.products updated  →  page re-renders automatically
```

That's it — add products from your phone, they appear on shoppers' screens in under a second.
