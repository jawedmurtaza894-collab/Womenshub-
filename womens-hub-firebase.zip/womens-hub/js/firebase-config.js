/* ============================================================
   Women's Hub — Firebase Configuration
   ------------------------------------------------------------
   👉  PASTE YOUR FIREBASE CONFIG HERE.
   Get it from:  Firebase Console → Project Settings →
                 "Your apps" → Web app → SDK setup → "Config"
   ============================================================ */
window.WH_FIREBASE_CONFIG = {
  apiKey:            "PASTE_API_KEY_HERE",
  authDomain:        "your-project.firebaseapp.com",
  projectId:         "your-project",
  storageBucket:     "your-project.appspot.com",
  messagingSenderId: "0000000000",
  appId:             "1:0000000000:web:xxxxxxxxxxxxxxxx"
};

/* The email address that is allowed to access /admin/.
   Create this user in Firebase Console → Authentication → Users → "Add user". */
window.WH_ADMIN_EMAIL = "admin@womenshub.com";
