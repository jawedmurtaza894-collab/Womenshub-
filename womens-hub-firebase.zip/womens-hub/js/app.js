/* ============================================================
   Women's Hub — Core Application JS
   Handles: state, cart, wishlist, auth, orders, notifications,
   navigation, theme, language, real-time sync (across tabs).
   Uses localStorage as a mock database.
   ============================================================ */

const WH = {
  /* ---------- Config ---------- */
  WHATSAPP: "03074865677",      // Customer support WhatsApp
  EASYPAISA: "03082900117",      // EasyPaisa payment number
  STORE_NAME: "Women's Hub",
  CURRENCY: "₨",
  ADMIN_EMAIL: "admin@womenshub.com",
  ADMIN_PASS: "admin123",

  /* ---------- State ---------- */
  state: {
    cart: [],
    wishlist: [],
    recent: [],
    user: null,
    orders: [],
    notifications: [],
    reviews: [],
    products: [],
    theme: "light",
    lang: "en"
  },

  /* ---------- Storage ---------- */
  load() {
    try {
      this.state.cart        = JSON.parse(localStorage.getItem("wh_cart")        || "[]");
      this.state.wishlist    = JSON.parse(localStorage.getItem("wh_wishlist")    || "[]");
      this.state.recent      = JSON.parse(localStorage.getItem("wh_recent")      || "[]");
      this.state.user        = JSON.parse(localStorage.getItem("wh_user")        || "null");
      this.state.orders      = JSON.parse(localStorage.getItem("wh_orders")      || "[]");
      this.state.notifications = JSON.parse(localStorage.getItem("wh_notifications") || "[]");
      this.state.reviews     = JSON.parse(localStorage.getItem("wh_reviews")     || "[]");
      this.state.theme       = localStorage.getItem("wh_theme") || "light";
      this.state.lang        = localStorage.getItem("wh_lang")  || "en";
      // Products: load saved admin edits, otherwise fallback
      const savedProducts = localStorage.getItem("wh_products");
      this.state.products = savedProducts ? JSON.parse(savedProducts) : (window.WH_PRODUCTS || []);
    } catch (e) { console.warn("Load error", e); }
  },

  save(key) {
    const map = {
      cart: "wh_cart", wishlist: "wh_wishlist", recent: "wh_recent",
      user: "wh_user", orders: "wh_orders", notifications: "wh_notifications",
      reviews: "wh_reviews", products: "wh_products"
    };
    if (key && map[key]) localStorage.setItem(map[key], JSON.stringify(this.state[key]));
    // broadcast change to other tabs
    localStorage.setItem("wh_sync", Date.now() + ":" + (key||""));
  },

  /* ---------- Currency ---------- */
  fmt(n) { return this.CURRENCY + " " + Number(n).toLocaleString("en-US"); },

  /* ---------- Theme ---------- */
  applyTheme() {
    document.body.classList.toggle("dark", this.state.theme === "dark");
  },
  toggleTheme() {
    this.state.theme = this.state.theme === "dark" ? "light" : "dark";
    localStorage.setItem("wh_theme", this.state.theme);
    this.applyTheme();
    this.toast("Theme changed", this.state.theme === "dark" ? "Dark mode enabled" : "Light mode enabled");
  },

  /* ---------- Language (simple EN/UR) ---------- */
  i18n: {
    en: { search: "Search luxury products...", cart: "Shopping Bag", wish: "Wishlist", add: "Add to Bag" },
    ur: { search: "پریمیم پروڈکٹس تلاش کریں...", cart: "خریداری بیگ", wish: "پسندیدہ", add: "بیگ میں شامل کریں" }
  },
  t(k) { return (this.i18n[this.state.lang] || this.i18n.en)[k] || k; },
  toggleLang() {
    this.state.lang = this.state.lang === "en" ? "ur" : "en";
    localStorage.setItem("wh_lang", this.state.lang);
    this.toast("Language", this.state.lang === "ur" ? "اردو میں تبدیل ہو گیا" : "Switched to English");
    setTimeout(() => location.reload(), 600);
  },

  /* ---------- Cart ---------- */
  findProduct(id) { return this.state.products.find(p => p.id === id); },
  cartCount() { return this.state.cart.reduce((s, i) => s + i.qty, 0); },
  cartTotal() {
    return this.state.cart.reduce((s, i) => {
      const p = this.findProduct(i.id); return p ? s + (p.price * i.qty) : s;
    }, 0);
  },
  addToCart(id, qty=1, opts={}) {
    const p = this.findProduct(id); if (!p) return;
    if (p.stock <= 0) { this.toast("Out of stock", p.name, "danger"); return; }
    const key = id + "|" + (opts.color||"") + "|" + (opts.size||"");
    const existing = this.state.cart.find(i => i.key === key);
    if (existing) existing.qty += qty;
    else this.state.cart.push({ key, id, qty, color: opts.color, size: opts.size });
    this.save("cart");
    this.renderCartCount();
    this.toast("Added to bag", p.name, "success");
  },
  updateCartQty(key, delta) {
    const it = this.state.cart.find(i => i.key === key); if (!it) return;
    it.qty = Math.max(1, it.qty + delta);
    this.save("cart");
  },
  removeFromCart(key) {
    this.state.cart = this.state.cart.filter(i => i.key !== key);
    this.save("cart");
    this.renderCartCount();
    this.renderCartDrawer();
  },
  clearCart() { this.state.cart = []; this.save("cart"); this.renderCartCount(); },

  /* ---------- Wishlist ---------- */
  inWishlist(id) { return this.state.wishlist.includes(id); },
  toggleWishlist(id) {
    if (this.inWishlist(id)) this.state.wishlist = this.state.wishlist.filter(x => x !== id);
    else { this.state.wishlist.push(id); this.toast("Saved to wishlist", this.findProduct(id)?.name || ""); }
    this.save("wishlist");
    this.renderWishlistCount();
    document.querySelectorAll(`[data-wish="${id}"]`).forEach(el => el.classList.toggle("active", this.inWishlist(id)));
  },

  /* ---------- Recently viewed ---------- */
  addRecent(id) {
    this.state.recent = [id, ...this.state.recent.filter(x => x !== id)].slice(0, 8);
    this.save("recent");
  },

  /* ---------- Auth ---------- */
  signup({ name, email, password }) {
    const users = JSON.parse(localStorage.getItem("wh_users") || "[]");
    if (users.find(u => u.email === email)) { this.toast("Account exists", "Try logging in instead", "danger"); return false; }
    const user = { id: "u" + Date.now(), name, email, password: btoa(password), createdAt: Date.now() };
    users.push(user);
    localStorage.setItem("wh_users", JSON.stringify(users));
    this.state.user = { id: user.id, name: user.name, email: user.email };
    this.save("user");
    this.toast("Welcome!", `Hello, ${name}`, "success");
    return true;
  },
  login(email, password) {
    if (email === this.ADMIN_EMAIL && password === this.ADMIN_PASS) {
      this.state.user = { id: "admin", name: "Admin", email, role: "admin" };
      this.save("user");
      this.toast("Admin login", "Welcome back", "success");
      setTimeout(() => location.href = "../admin/index.html", 600);
      return true;
    }
    const users = JSON.parse(localStorage.getItem("wh_users") || "[]");
    const user = users.find(u => u.email === email && u.password === btoa(password));
    if (!user) { this.toast("Invalid login", "Check email/password", "danger"); return false; }
    this.state.user = { id: user.id, name: user.name, email: user.email };
    this.save("user");
    this.toast("Welcome back", user.name, "success");
    return true;
  },
  googleLogin() {
    // Simulated Google sign-in (frontend-only demo)
    const name = "Google User";
    const email = "google.user@gmail.com";
    this.state.user = { id: "g" + Date.now(), name, email, provider: "google" };
    this.save("user");
    this.toast("Signed in", "Connected with Google", "success");
    setTimeout(() => location.href = "dashboard.html", 600);
  },
  logout() {
    this.state.user = null;
    this.save("user");
    this.toast("Logged out", "Come back soon");
    setTimeout(() => location.href = "../index.html", 500);
  },

  /* ---------- Orders ---------- */
  createOrder(payload) {
    const id = "WH-" + Math.floor(100000 + Math.random() * 900000);
    const order = {
      id, ...payload,
      createdAt: Date.now(),
      status: "Order Confirmed",
      paymentStatus: payload.paymentMethod === "easypaisa" ? "Pending" : (payload.paymentMethod === "cod" ? "COD" : "Verified"),
      timeline: [{ status: "Order Confirmed", date: Date.now(), note: "Thanks for ordering — we're preparing your luxury package." }],
      estimatedDelivery: Date.now() + 5 * 86400000
    };
    this.state.orders.unshift(order);
    this.save("orders");
    // Real-time notification to admin
    this.pushNotification({
      type: "order",
      title: "🎉 New Order Received",
      message: `Order ${id} • ${this.fmt(order.total)} • ${order.customer.name}`,
      orderId: id,
      sound: true
    });
    return order;
  },
  updateOrderStatus(orderId, newStatus, note="") {
    const o = this.state.orders.find(x => x.id === orderId); if (!o) return;
    o.status = newStatus;
    o.timeline.push({ status: newStatus, date: Date.now(), note });
    this.save("orders");
    this.pushNotification({
      type: "status",
      title: "Order Update",
      message: `Order ${orderId} → ${newStatus}`,
      orderId
    });
  },
  verifyPayment(orderId, status, note="") {
    const o = this.state.orders.find(x => x.id === orderId); if (!o) return;
    o.paymentStatus = status;
    o.timeline.push({ status: "Payment " + status, date: Date.now(), note });
    this.save("orders");
  },

  /* ---------- Notifications ---------- */
  pushNotification(n) {
    n.id = "n" + Date.now() + Math.random().toString(36).slice(2,6);
    n.createdAt = Date.now();
    n.read = false;
    this.state.notifications.unshift(n);
    if (this.state.notifications.length > 50) this.state.notifications.length = 50;
    this.save("notifications");
    if (n.sound) this.playNotifSound();
  },
  playNotifSound() {
    // Generate a soft chime via Web Audio (no external file)
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playTone = (freq, time, dur=0.18) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = "sine"; osc.frequency.value = freq;
        gain.gain.setValueAtTime(0, ctx.currentTime + time);
        gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + time + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + time + dur);
        osc.start(ctx.currentTime + time);
        osc.stop(ctx.currentTime + time + dur);
      };
      playTone(880, 0); playTone(1175, 0.14); playTone(1568, 0.28, 0.32);
    } catch (e) {}
  },

  /* ---------- Reviews ---------- */
  addReview({ productId, rating, text }) {
    if (!this.state.user) { this.toast("Please log in", "Login to leave a review", "danger"); return false; }
    // verify the user has purchased this product
    const hasPurchased = this.state.orders.some(o =>
      o.customer.email === this.state.user.email &&
      o.items.some(i => i.id === productId)
    );
    if (!hasPurchased) { this.toast("Verified buyers only", "Only verified buyers can review", "danger"); return false; }
    const review = {
      id: "r" + Date.now(),
      productId,
      userId: this.state.user.id,
      userName: this.state.user.name,
      rating, text,
      verified: true,
      status: "pending", // requires admin approval
      createdAt: Date.now()
    };
    this.state.reviews.push(review);
    this.save("reviews");
    this.toast("Review submitted", "Pending approval", "success");
    return true;
  },
  approvedReviews(productId) {
    return this.state.reviews.filter(r => r.productId === productId && r.status === "approved");
  },

  /* ---------- Coupons ---------- */
  validateCoupon(code) {
    const map = {
      "LUXE10": { discount: 10, type: "percent", min: 0 },
      "PREMIUM20": { discount: 20, type: "percent", min: 10000 },
      "WELCOME500": { discount: 500, type: "flat", min: 2000 }
    };
    return map[code.toUpperCase()] || null;
  },

  /* ---------- UI Helpers ---------- */
  toast(title, msg="", type="default") {
    let wrap = document.querySelector(".toast-wrap");
    if (!wrap) { wrap = document.createElement("div"); wrap.className = "toast-wrap"; document.body.appendChild(wrap); }
    const el = document.createElement("div");
    el.className = "toast " + type;
    const icon = type === "success" ? "✓" : type === "danger" ? "✕" : "✦";
    el.innerHTML = `<div class="ti">${icon}</div><div><strong>${title}</strong>${msg ? `<small>${msg}</small>` : ""}</div>`;
    wrap.appendChild(el);
    setTimeout(() => { el.style.animation = "slideIn .3s reverse"; setTimeout(() => el.remove(), 300); }, 3200);
  },

  renderCartCount() {
    const els = document.querySelectorAll("[data-cart-count]");
    const n = this.cartCount();
    els.forEach(el => { el.textContent = n; el.style.display = n ? "flex" : "none"; });
  },
  renderWishlistCount() {
    const els = document.querySelectorAll("[data-wish-count]");
    const n = this.state.wishlist.length;
    els.forEach(el => { el.textContent = n; el.style.display = n ? "flex" : "none"; });
  },

  /* ---------- Cart Drawer ---------- */
  renderCartDrawer() {
    const body = document.querySelector("#cartDrawer .drawer-body");
    const foot = document.querySelector("#cartDrawer .drawer-foot");
    if (!body) return;
    if (this.state.cart.length === 0) {
      body.innerHTML = `<div style="text-align:center;padding:60px 0;">
        <div style="font-size:60px;opacity:.3;">🛍</div>
        <h3 style="margin:14px 0 6px;">Your bag is empty</h3>
        <p style="color:var(--gray);font-size:13px;">Start shopping our luxury collection</p>
        <a href="${this.pathPrefix()}pages/shop.html" class="btn btn-primary" style="margin-top:20px;">Browse Shop</a>
      </div>`;
      foot.innerHTML = "";
      return;
    }
    body.innerHTML = this.state.cart.map(i => {
      const p = this.findProduct(i.id); if (!p) return "";
      return `
        <div class="cart-item">
          <img src="${p.images[0]}" alt="${p.name}">
          <div class="ci-info">
            <h4>${p.name}</h4>
            <div class="ci-meta">${i.color ? `<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${i.color};vertical-align:middle;margin-right:6px;border:1px solid var(--gray-line);"></span>` : ""}${i.size || ""}</div>
            <div class="ci-price">${this.fmt(p.price * i.qty)}</div>
            <div class="qty">
              <button onclick="WH.updateCartQty('${i.key}', -1); WH.renderCartDrawer(); WH.renderCartCount();">−</button>
              <span>${i.qty}</span>
              <button onclick="WH.updateCartQty('${i.key}', 1); WH.renderCartDrawer(); WH.renderCartCount();">+</button>
            </div>
            <div class="ci-remove" onclick="WH.removeFromCart('${i.key}')">Remove</div>
          </div>
        </div>`;
    }).join("");
    const subtotal = this.cartTotal();
    const shipping = subtotal > 5000 ? 0 : 250;
    foot.innerHTML = `
      <div class="cart-totals">
        <div class="row"><span>Subtotal</span><strong>${this.fmt(subtotal)}</strong></div>
        <div class="row"><span>Shipping</span><strong>${shipping === 0 ? "Free" : this.fmt(shipping)}</strong></div>
        <div class="row total"><span>Total</span><strong>${this.fmt(subtotal + shipping)}</strong></div>
      </div>
      <a href="${this.pathPrefix()}pages/checkout.html" class="btn btn-primary btn-block">Checkout →</a>
      <a href="${this.pathPrefix()}pages/cart.html" class="btn btn-outline btn-block" style="margin-top:8px;">View Bag</a>`;
  },

  pathPrefix() {
    // figure out if we're in a sub-folder
    const p = location.pathname;
    if (p.includes("/pages/") || p.includes("/admin/")) return "../";
    return "";
  },

  /* ---------- WhatsApp helpers ---------- */
  waLink(message="") {
    const text = encodeURIComponent(message || `Hi Women's Hub, I'd like to know more about your products.`);
    return `https://wa.me/92${this.WHATSAPP.replace(/^0/, "")}?text=${text}`;
  },
  waProductLink(product) {
    const msg = `Hi! I'd like to order:\n\n*${product.name}*\nCategory: ${product.category}\nPrice: ${this.fmt(product.price)}\n\nPlease confirm availability.`;
    return this.waLink(msg);
  },

  /* ---------- Init common UI ---------- */
  initHeader() {
    this.renderCartCount();
    this.renderWishlistCount();
    // theme toggle
    document.querySelectorAll("[data-theme-toggle]").forEach(b => b.onclick = () => this.toggleTheme());
    // lang toggle
    document.querySelectorAll("[data-lang-toggle]").forEach(b => b.onclick = () => this.toggleLang());
    // cart drawer open
    document.querySelectorAll("[data-open-cart]").forEach(b => b.onclick = (e) => {
      e.preventDefault();
      this.renderCartDrawer();
      document.querySelector("#cartDrawer")?.classList.add("open");
      document.querySelector("#drawerOverlay")?.classList.add("open");
    });
    // drawer close
    document.querySelectorAll("[data-close-drawer]").forEach(b => b.onclick = () => {
      document.querySelectorAll(".drawer").forEach(d => d.classList.remove("open"));
      document.querySelector("#drawerOverlay")?.classList.remove("open");
    });
    document.querySelector("#drawerOverlay")?.addEventListener("click", () => {
      document.querySelectorAll(".drawer").forEach(d => d.classList.remove("open"));
      document.querySelector("#drawerOverlay")?.classList.remove("open");
    });
    // mobile menu
    document.querySelectorAll("[data-open-menu]").forEach(b => b.onclick = () => {
      document.querySelector("#mobileMenu")?.classList.add("open");
    });
    document.querySelectorAll("[data-close-menu]").forEach(b => b.onclick = () => {
      document.querySelector("#mobileMenu")?.classList.remove("open");
    });

    // scroll-to-top
    const st = document.querySelector(".scroll-top");
    if (st) {
      window.addEventListener("scroll", () => st.classList.toggle("visible", window.scrollY > 600));
      st.onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });
    }

    this.applyTheme();
  },

  /* ---------- Cross-tab realtime ---------- */
  initRealtimeSync() {
    window.addEventListener("storage", (e) => {
      if (!e.key) return;
      if (e.key === "wh_sync" || e.key.startsWith("wh_")) {
        this.load();
        this.renderCartCount?.();
        this.renderWishlistCount?.();
        // notify admin if new order
        if (window.AdminDashboard && typeof window.AdminDashboard.refresh === "function") {
          window.AdminDashboard.refresh();
        }
      }
    });
  }
};

/* ---------- Boot ---------- */
WH.load();
document.addEventListener("DOMContentLoaded", () => {
  WH.initHeader();
  WH.initRealtimeSync();
});

window.WH = WH;

/* ============================================================
   Firebase auto-bootstrap (added by upgrade)
   ============================================================ */
(function loadFirebaseBootstrap() {
  const here = location.pathname.replace(/[^/]+$/, "");
  const base = here.includes("/admin/") || here.includes("/pages/") ? "../js/" : "js/";
  const s = document.createElement("script");
  s.src = base + "firebase-bootstrap.js";
  document.head.appendChild(s);
})();
