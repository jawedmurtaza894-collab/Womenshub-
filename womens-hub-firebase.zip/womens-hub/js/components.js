/* ============================================================
   Women's Hub — Reusable HTML Components (injected via JS)
   Header, Footer, Drawers, Floating WhatsApp.
   Path prefix auto-detected so it works from / and /pages/.
   ============================================================ */

const PFX = (location.pathname.includes("/pages/") || location.pathname.includes("/admin/")) ? "../" : "";

const HEADER_HTML = `
<div class="topbar">
  <div class="marquee">
    <span>✦ FREE SHIPPING ON ORDERS OVER ₨ 5,000</span>
    <span>✦ LUXURY PACKAGING ON EVERY ORDER</span>
    <span>✦ 30-DAY RETURNS WORLDWIDE</span>
    <span>✦ NEW DROPS EVERY FRIDAY</span>
    <span>✦ FREE SHIPPING ON ORDERS OVER ₨ 5,000</span>
    <span>✦ LUXURY PACKAGING ON EVERY ORDER</span>
    <span>✦ 30-DAY RETURNS WORLDWIDE</span>
    <span>✦ NEW DROPS EVERY FRIDAY</span>
  </div>
</div>
<header class="site-header">
  <div class="container header-inner">
    <a href="${PFX}index.html" class="logo">
      <span class="logo-mark">W</span>
      <div class="logo-text">Women's Hub<small>Luxury · Curated</small></div>
    </a>
    <nav class="main-nav">
      <a href="${PFX}index.html">Home</a>
      <a href="${PFX}pages/shop.html">Shop</a>
      <a href="${PFX}pages/shop.html?cat=Fashion">Fashion</a>
      <a href="${PFX}pages/shop.html?cat=Beauty">Beauty</a>
      <a href="${PFX}pages/shop.html?cat=Jewelry">Jewelry</a>
      <a href="${PFX}pages/about.html">About</a>
      <a href="${PFX}pages/contact.html">Contact</a>
    </nav>
    <div class="header-actions">
      <button class="icon-btn" data-theme-toggle title="Toggle theme">🌙</button>
      <button class="icon-btn" data-lang-toggle title="Language">EN</button>
      <a href="${PFX}pages/wishlist.html" class="icon-btn" title="Wishlist">♡<span class="badge" data-wish-count style="display:none">0</span></a>
      <a href="${PFX}pages/login.html" class="icon-btn" title="Account">👤</a>
      <button class="icon-btn" data-open-cart title="Cart">🛍<span class="badge" data-cart-count style="display:none">0</span></button>
      <button class="icon-btn mobile-toggle" data-open-menu title="Menu">☰</button>
    </div>
  </div>
</header>`;

const FOOTER_HTML = `
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="logo">
          <span class="logo-mark">W</span>
          <div class="logo-text">Women's Hub<small>Luxury · Curated</small></div>
        </div>
        <p>A premium luxury destination curated for the modern woman. Hand-selected pieces, signature packaging, worldwide delivery.</p>
        <div class="socials">
          <a href="#" aria-label="Instagram">📷</a>
          <a href="#" aria-label="Facebook">f</a>
          <a href="#" aria-label="TikTok">🎵</a>
          <a href="#" aria-label="Pinterest">P</a>
          <a href="https://wa.me/92${WH.WHATSAPP.replace(/^0/,"")}" aria-label="WhatsApp">💬</a>
        </div>
      </div>
      <div>
        <h4>Shop</h4>
        <ul>
          <li><a href="${PFX}pages/shop.html?cat=Fashion">Fashion</a></li>
          <li><a href="${PFX}pages/shop.html?cat=Beauty">Beauty</a></li>
          <li><a href="${PFX}pages/shop.html?cat=Jewelry">Jewelry</a></li>
          <li><a href="${PFX}pages/shop.html?cat=Bags">Bags</a></li>
          <li><a href="${PFX}pages/shop.html?tag=new">New Arrivals</a></li>
          <li><a href="${PFX}pages/shop.html?tag=bestseller">Best Sellers</a></li>
        </ul>
      </div>
      <div>
        <h4>Help</h4>
        <ul>
          <li><a href="${PFX}pages/contact.html">Contact</a></li>
          <li><a href="${PFX}pages/faq.html">FAQ</a></li>
          <li><a href="${PFX}pages/track.html">Track Order</a></li>
          <li><a href="${PFX}pages/dashboard.html">My Account</a></li>
          <li><a href="${PFX}pages/faq.html#shipping">Shipping</a></li>
          <li><a href="${PFX}pages/faq.html#returns">Returns</a></li>
        </ul>
      </div>
      <div>
        <h4>Company</h4>
        <ul>
          <li><a href="${PFX}pages/about.html">About Us</a></li>
          <li><a href="${PFX}pages/privacy.html">Privacy Policy</a></li>
          <li><a href="${PFX}pages/terms.html">Terms & Conditions</a></li>
          <li><a href="${PFX}pages/faq.html">Customer Care</a></li>
        </ul>
      </div>
      <div>
        <h4>Contact</h4>
        <p style="font-size:13px;margin-bottom:10px;"><strong>WhatsApp Support</strong><br>
        <a href="https://wa.me/92${WH.WHATSAPP.replace(/^0/,"")}" style="color:#25d366;font-weight:600;">+92 ${WH.WHATSAPP.slice(1)}</a></p>
        <p style="font-size:13px;">support@womenshub.com<br>Karachi · Lahore · Islamabad</p>
        <p style="font-size:12px;margin-top:14px;">Admin login:<br>
          <code style="background:var(--bg-card);padding:3px 6px;border-radius:4px;font-size:11px;">admin@womenshub.com / admin123</code></p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© ${new Date().getFullYear()} Women's Hub · All rights reserved.</span>
      <span>Made with ♡ for women who love beautiful things.</span>
    </div>
  </div>
</footer>`;

const DRAWER_HTML = `
<div class="drawer-overlay" id="drawerOverlay"></div>
<aside class="drawer" id="cartDrawer">
  <div class="drawer-head">
    <h3>Your Bag</h3>
    <button class="close" data-close-drawer aria-label="Close">×</button>
  </div>
  <div class="drawer-body"></div>
  <div class="drawer-foot"></div>
</aside>
<div class="mobile-menu" id="mobileMenu">
  <div class="mm-head">
    <span class="logo"><span class="logo-mark">W</span><div class="logo-text">Women's Hub</div></span>
    <button class="close" data-close-menu style="font-size:24px;">×</button>
  </div>
  <a href="${PFX}index.html">Home</a>
  <a href="${PFX}pages/shop.html">Shop</a>
  <a href="${PFX}pages/shop.html?cat=Fashion">Fashion</a>
  <a href="${PFX}pages/shop.html?cat=Beauty">Beauty</a>
  <a href="${PFX}pages/shop.html?cat=Jewelry">Jewelry</a>
  <a href="${PFX}pages/wishlist.html">Wishlist</a>
  <a href="${PFX}pages/track.html">Track Order</a>
  <a href="${PFX}pages/about.html">About</a>
  <a href="${PFX}pages/contact.html">Contact</a>
  <a href="${PFX}pages/login.html" style="color:var(--gold-deep);">Login / Register</a>
</div>
<a href="https://wa.me/92${WH.WHATSAPP.replace(/^0/,"")}?text=Hi%20Women's%20Hub" class="float-whatsapp" target="_blank" aria-label="Chat on WhatsApp">💬</a>
<button class="scroll-top" aria-label="Scroll to top">↑</button>`;

/* ---------- Product Card ---------- */
function productCardHTML(p) {
  const save = Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100);
  const colors = (p.colors || []).slice(0, 4).map(c => `<span style="background:${c}"></span>`).join("");
  const wished = WH.inWishlist(p.id);
  return `
  <div class="product-card fade-in">
    <div class="pc-img">
      ${p.badge ? `<span class="pc-badge ${p.badge === 'Bestseller' || p.badge === 'Luxury' ? 'gold':''}">${p.badge}</span>` : ""}
      <span class="pc-wish ${wished ? 'active':''}" data-wish="${p.id}" onclick="event.preventDefault();WH.toggleWishlist('${p.id}')">♡</span>
      <a href="${PFX}pages/product.html?id=${p.id}">
        <img src="${p.images[0]}" alt="${p.name}" loading="lazy">
      </a>
      <div class="pc-hover">
        <button class="btn btn-primary btn-sm btn-block" onclick="WH.addToCart('${p.id}',1,{color:'${(p.colors||[])[0]||''}',size:'${(p.sizes||['One Size'])[0]}'})">Quick Add</button>
      </div>
    </div>
    <div class="pc-body">
      <div class="pc-cat">${p.category}</div>
      <h3 class="pc-name"><a href="${PFX}pages/product.html?id=${p.id}">${p.name}</a></h3>
      <div class="pc-rating">
        <span class="stars">${"★".repeat(Math.round(p.rating))}${"☆".repeat(5-Math.round(p.rating))}</span>
        <span>${p.rating} (${p.reviews})</span>
      </div>
      <div class="pc-price">
        <span class="now">${WH.fmt(p.price)}</span>
        ${p.oldPrice ? `<span class="old">${WH.fmt(p.oldPrice)}</span><span class="save">-${save}%</span>` : ""}
      </div>
      ${colors ? `<div class="pc-colors">${colors}</div>` : ""}
    </div>
  </div>`;
}

/* ---------- Mount ---------- */
function mountComponents() {
  const headerSlot = document.querySelector("#header-slot");
  const footerSlot = document.querySelector("#footer-slot");
  const drawerSlot = document.querySelector("#drawer-slot");
  if (headerSlot) headerSlot.innerHTML = HEADER_HTML;
  if (footerSlot) footerSlot.innerHTML = FOOTER_HTML;
  if (drawerSlot) drawerSlot.innerHTML = DRAWER_HTML;
}

document.addEventListener("DOMContentLoaded", () => {
  mountComponents();
  WH.initHeader();
});

window.productCardHTML = productCardHTML;
window.PFX = PFX;
