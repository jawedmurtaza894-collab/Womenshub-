/* ============================================================
   Women's Hub — Sample Product Database
   Mixed catalog: Fashion + Beauty + Accessories + Jewelry
   All images are licensed (Pexels / Pickpik / Rawpixel / Stockcake)
   ============================================================ */
window.WH_PRODUCTS = [
  {
    id: "p001",
    name: "Nude Trench Coat — Signature Collection",
    category: "Fashion",
    price: 14990,
    oldPrice: 19990,
    rating: 4.9,
    reviews: 128,
    stock: 12,
    badge: "Bestseller",
    description: "A tailored nude trench coat in soft premium wool blend. Effortlessly elegant for any season — designed in Milan, finished by hand.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=aahS9WR%2FodvrFh%2FZjenHtLXyA1ntwZYkjDR0dHp1I0iCjj8ZGIL0MgVRxTNCVIRoNnBEIgN2Tdag0IJiY7W0Ao7zfW4wi7vu96TD87us8IGvvIWXHNXQnlIdfmhylKpv&u2=3nX63Uerx0so2S3F&width=2560",
      "https://sspark.genspark.ai/cfimages?u1=qwEjGs2z4ksQ4B8JI3u%2ByI9Sc8uHZb1N16sq2xklIPOgEzT8osfGSdNXs9x%2FCoUmJMa4DaDciouymaw9PAoa4Lduc1DqqzNlDqxgO6%2BxuTdPXg%3D%3D&u2=I8xyq7i%2BG%2FIgnlKk&width=2560"
    ],
    colors: ["#d8c4a3", "#000000", "#f5e6d3"],
    sizes: ["XS", "S", "M", "L", "XL"],
    tags: ["new", "trending", "fashion"]
  },
  {
    id: "p002",
    name: "Classic Beige Suit — Powerwear Edit",
    category: "Fashion",
    price: 22500,
    oldPrice: 27000,
    rating: 4.8,
    reviews: 94,
    stock: 7,
    badge: "Editor's Pick",
    description: "Sharp tailoring meets feminine grace. This two-piece beige suit is your power statement — boardroom to brunch.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=qwEjGs2z4ksQ4B8JI3u%2ByI9Sc8uHZb1N16sq2xklIPOgEzT8osfGSdNXs9x%2FCoUmJMa4DaDciouymaw9PAoa4Lduc1DqqzNlDqxgO6%2BxuTdPXg%3D%3D&u2=I8xyq7i%2BG%2FIgnlKk&width=2560",
      "https://sspark.genspark.ai/cfimages?u1=zKvHUwmjA9%2F94OJR0CT9hSP3zznhUY46YkljbMxYjjyq0OavdCm5ufTDvuwsG3ybj%2Fuz%2Bgd2Ytua2y1QfgWjt%2BEHTo4o8ic5PMinaOAoKxfO5lOih%2BhCBZGmpyDHeL9C&u2=GTDz1OKWb%2BxIc%2BDD&width=2560"
    ],
    colors: ["#d8c4a3", "#ffffff", "#1a1a1a"],
    sizes: ["S", "M", "L"],
    tags: ["bestseller", "fashion"]
  },
  {
    id: "p003",
    name: "Beige Belted Pantsuit",
    category: "Fashion",
    price: 18900,
    oldPrice: 23900,
    rating: 4.7,
    reviews: 76,
    stock: 9,
    badge: "Trending",
    description: "Belted at the waist for a refined silhouette. Tailored from a soft viscose blend with subtle sheen.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=7xXfVwL3W%2BWIHESmLNxLdwW0Tz33QNc5Cha81g3Acaxu5rm%2FQLjEVtwO8BPVRbEYxVNRUfHwdbcGZS1C%2BV3xUflbK7mQ95g%2FhdsbmQJRSpYhMffUZWmIKz8W5w%2FxTYeW&u2=Hdr1tKz35xasg8hd&width=2560"
    ],
    colors: ["#d8c4a3", "#c8b59a"],
    sizes: ["XS", "S", "M", "L"],
    tags: ["trending", "fashion"]
  },
  {
    id: "p004",
    name: "Desert Bloom Maxi Dress",
    category: "Fashion",
    price: 9990,
    oldPrice: 12990,
    rating: 4.9,
    reviews: 211,
    stock: 18,
    badge: "Bestseller",
    description: "Flowing maxi in warm beige tones — designed for golden-hour moments and weekend getaways.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=WsXV%2FxqLfbHagEnqGgIecskBferAZrraOqN1hDNmjSAQGNp5As3zo%2BhttWvGKo3tISXNE6OH0VeR81eeuxU150LNo9whOy21JUv1eJsGiKSPXpBhP3Qk3DTxwfQqnK4gZbCA%2BN4uNK9zLafd9TNpVu9PRwGsfr9Eqs0UIsPG%2F%2BiofhdYxMRuW7HZ%2BNaA8%2FpiiPtJjQ%3D%3D&u2=K%2BtH%2Fi0%2FKxeykvy7&width=2560"
    ],
    colors: ["#d8c4a3", "#e8d5c4", "#000000"],
    sizes: ["XS", "S", "M", "L", "XL"],
    tags: ["bestseller", "trending", "fashion", "new"]
  },
  {
    id: "p005",
    name: "White Tailored Blazer Set",
    category: "Fashion",
    price: 16500,
    oldPrice: 19500,
    rating: 4.6,
    reviews: 58,
    stock: 11,
    badge: "New",
    description: "Crisp white blazer with matching skirt. A timeless silhouette for the modern minimalist.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=B8Yb6NBiH%2FJFC3103SRpp2BOd1gmujZrHau1NWGGD0tVITPsog7qRPMV6kk2komLu1bSuNdEiBWneYiaRxodfoB%2Fazk8UVLwHj8QAOhpzloYUScUBbC52Eqi4U9jy5cq5FEtL5r5oA%3D%3D&u2=ggJpnxL0wSJqZ4MP&width=2560"
    ],
    colors: ["#ffffff", "#f5e6d3"],
    sizes: ["S", "M", "L"],
    tags: ["new", "fashion"]
  },
  {
    id: "p006",
    name: "Beige Premium Tote Bag",
    category: "Bags",
    price: 7990,
    oldPrice: 10990,
    rating: 4.8,
    reviews: 167,
    stock: 22,
    badge: "Bestseller",
    description: "Genuine leather tote in soft beige. Spacious, structured, and finished with gold-tone hardware.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=igHbXeM%2B68MZqyJsu2SPLJ2mQ3eY%2F1i4Cn6p6OickA5LU2oHaVdYvPjSxZQWiDI9BeoDf7oeo3FFvdGz8hEU99obltF2b2S93JUt%2FK3mbNR0gUmQXezu5WGS8H1hC1y0UGniE%2BTxZoOj%2FRdraXi5pEGLIDDGUZECUR6M&u2=BB48CaymAqt5OjEz&width=2560",
      "https://sspark.genspark.ai/cfimages?u1=vuQBz%2B0%2F4D%2BZTkn9fEqoehTa4P99bwaRmo98YUJapbyJ5axQXJx367T8bbDxkSLyrAoyRceYwtQkULZ4EaGV7Ouwa146cp7O7nBZWMpmNZcUWWEah%2BVOVWfG8adZhSXdwKZ5%2BXVrA7xFBIMnWK79LJzWJ%2B%2BPOkans7o%3D&u2=eRF2g2d64RdQKkWf&width=2560"
    ],
    colors: ["#d8c4a3", "#000000", "#8b6f47"],
    sizes: ["One Size"],
    tags: ["bestseller", "bags"]
  },
  {
    id: "p007",
    name: "Onyx Mini Crossbody",
    category: "Bags",
    price: 5990,
    oldPrice: 7990,
    rating: 4.7,
    reviews: 89,
    stock: 15,
    badge: "Trending",
    description: "Compact, chic, and crafted for modern silhouettes. Detachable strap, magnetic closure.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=EmvAddxSVxZiD1yjGn1vedW8NfmrSlfC5h1ydVysQObF5SxABKDAcsShYidIEaGDbnkLHsENGbTggJNGn%2FxcVse4UVKCt955bM%2BndPyqi75oQdKZdnrX8kA43vRtWYipDbv1pH%2Bl6tXDfsPPb5xPMlkAqv4nks7WfKzQ9aRvo2w%3D&u2=oCokj5VFZrdHHNg9&width=2560"
    ],
    colors: ["#000000", "#8b6f47"],
    sizes: ["One Size"],
    tags: ["trending", "bags"]
  },
  {
    id: "p008",
    name: "Emerald Heritage Handbag",
    category: "Bags",
    price: 8990,
    oldPrice: 11990,
    rating: 4.8,
    reviews: 102,
    stock: 9,
    badge: "Limited",
    description: "Deep emerald leather with hand-stitched detail. A statement piece in our heritage line.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=GEWKw6nJ4z241dsL1ksGmfGhI0RTbEZU6Zc2EvUeJFBmGUpkq%2B%2BNLLFamjn9dp6KvlXWeRJcMi5ol7FNZk66nWVRyDQ%2FkNIsI25kaXY9SYHwNBQb%2BVzlQKSobY%2Bj4%2BFLzUr8WbzPDPP9fDb0fH1TmI6Pt%2BEdhAdXxZTW6ueFb4w%3D&u2=cc4EEuFaTuxFNoR1&width=2560"
    ],
    colors: ["#1a4d3a", "#000000"],
    sizes: ["One Size"],
    tags: ["fashion", "bags"]
  },
  {
    id: "p009",
    name: "Caramel Soft Hobo Bag",
    category: "Bags",
    price: 6500,
    oldPrice: 8500,
    rating: 4.6,
    reviews: 71,
    stock: 14,
    description: "Buttery soft leather hobo in caramel. Slouchy, roomy, and irresistibly tactile.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=tzQNA1JDXyfyYariLWauZQlQxvWLCXuPxbcxVWoMQ4rYO0P6sWgKMME0lTBA0EVj2fgNLIcVgPgdd6mt5jP%2F%2BLp72QgXBHyDKo7EOQPYp2k6WWA2oWOw91HQKCDONrs%3D&u2=x8bgQYOQ8MkOiTTk&width=2560"
    ],
    colors: ["#a07b54", "#8b6f47"],
    sizes: ["One Size"],
    tags: ["bags"]
  },
  {
    id: "p010",
    name: "Rose Gold Highlighter Palette",
    category: "Beauty",
    price: 2490,
    oldPrice: 3490,
    rating: 4.9,
    reviews: 342,
    stock: 47,
    badge: "Bestseller",
    description: "Duochrome highlighter with radiant shimmer. Long-wearing pigment, buildable glow.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=lDhPqxnUSWv%2FhuvamQ8KocbFjLNDTFW8GgOJND%2Bqpp1qRcsnHWIwbUA%2F8Ktqt1wJ71N1Celbpd13jSVGxP8tsRaDAA%3D%3D&u2=tnuBrt3xlnY2v1Zy&width=2560",
      "https://sspark.genspark.ai/cfimages?u1=mZu9rXHPlJyD1Yxwy9Veak8SMEUD8PtBX0O5ouizsGDCNtPlcErK5MCLcdwO7FCV6s4VZRJdJw%2FN9OyWoOzdebmnV%2BXxSKqF6kaSM7YpgNu3uuZ6v2gWbJY%3D&u2=3U3HbNN073UQ7AMr&width=2560"
    ],
    colors: ["#f4c2c2", "#e8b4a8"],
    sizes: ["Standard"],
    tags: ["bestseller", "trending", "beauty"]
  },
  {
    id: "p011",
    name: "Premium Pink Gold Brush Set",
    category: "Beauty",
    price: 3990,
    oldPrice: 5990,
    rating: 4.8,
    reviews: 218,
    stock: 33,
    badge: "Trending",
    description: "10-piece premium brush set in pink-gold finish. Synthetic, vegan, ultra-soft bristles.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=A8sBuVq2ygrEcZTtPZmxcgoIC5o693Z%2FIkGvviVrjMkiJhkwX97jr0o8FvtLVy%2BI1n4TMH%2FnpVuvJbLTVFxnjVeMfRot2b5mpEn6bqMVyTXDmtMShXsWcag%3D&u2=cQ00HW0e7Brtrd2Z&width=2560"
    ],
    colors: ["#f4c2c2", "#d4a373"],
    sizes: ["10 Pieces"],
    tags: ["trending", "beauty"]
  },
  {
    id: "p012",
    name: "Crystal Beauty Brush Collection",
    category: "Beauty",
    price: 4500,
    oldPrice: 6500,
    rating: 4.7,
    reviews: 134,
    stock: 21,
    description: "8-piece crystal-handled brush set. The luxury edition for the discerning collector.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=sjrTuGxXiKhT944U7AbcF4cv39MT2NHvdrLYyzwvkkavxhdFBkRQnErbTiV86h%2Bd9GMBBEpRXBPuMTrFtw7goYLgTtejccI1YeNb2cp8Lsn5NNjkednoIv8ebl2y8RCKnuOK8jY8p4EDfoZ%2BAmkZLxVks6fl8CYmPu7ad9pmf1mtZhsgAMIajQa17JY%3D&u2=a0F7CMKNWxPXr8S4&width=2560"
    ],
    colors: ["#f4c2c2"],
    sizes: ["8 Pieces"],
    tags: ["beauty"]
  },
  {
    id: "p013",
    name: "Floating Beauty Essentials Kit",
    category: "Beauty",
    price: 5990,
    oldPrice: 7990,
    rating: 4.8,
    reviews: 89,
    stock: 17,
    badge: "New",
    description: "Curated beauty essentials kit — brushes, sponges, and tools. Everything she needs in one chic case.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=72erJHvUhoOkU18Ut6yPvXgumrQgjD8CRx8Sa4OpzhPaLgAVOzgRQ2zh%2FtYDOyT54cgZXASope4nKzaC4Ukok4DSe3riAnxuc13k194ZE%2Foj%2F9PpY5yqsbdG2Ecgkwz11CF24Nf%2BTzOjJOcNXxyIHBwzM%2B52zpuxJcV8p2yo%2BKW%2FnzjeMVIZWHO42%2BSU&u2=lHVxGnyV%2B0XODRoq&width=2560"
    ],
    colors: ["#f4c2c2", "#d4a373"],
    sizes: ["Standard Kit"],
    tags: ["new", "beauty"]
  },
  {
    id: "p014",
    name: "Rose Gold Skincare Ritual Set",
    category: "Beauty",
    price: 8990,
    oldPrice: 12990,
    rating: 4.9,
    reviews: 156,
    stock: 13,
    badge: "Luxury",
    description: "Anti-aging skincare ritual featuring 24K rose gold infusion. Cleanse, serum, moisturizer.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=sJnpvVL6HGoDEq9j%2BlbsaKOcD8A9WlFTxLuJu77O8dsBwO2%2FAisWv7iaMhhq0JYwoGZhC3JcPhKkFj4VfQam4hZdAYhG%2BloKHJ4bEftcdZSELzVmgQSBdY%2FGSDgs57WjImAgI47LSx1hfj4sdl9VjUvxGnJ%2FsA%3D%3D&u2=AGHN%2BkY9c7GeQenV&width=2560"
    ],
    colors: ["#f4c2c2"],
    sizes: ["Full Set"],
    tags: ["luxury", "beauty"]
  },
  {
    id: "p015",
    name: "Heirloom Gold Necklace",
    category: "Jewelry",
    price: 12990,
    oldPrice: 16990,
    rating: 4.9,
    reviews: 87,
    stock: 8,
    badge: "Limited",
    description: "Hand-finished 18K gold-plated necklace with delicate pendant. A modern heirloom in the making.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=wNwV3ivsowGYVhxkcEeht2POkvd2e1bq2XDrmqK%2Ft4FQUQIhs4jPCDkXQy99qWTSfr9CZj7tsO11%2BpUori922SNFAgf3jT48FDwze95k3S2GFzjRCiF0V9waqWNq3KE0oAhf%2BUDL4MPPi2g%3D&u2=Y8FZBar2mLad2bJe&width=2560",
      "https://sspark.genspark.ai/cfimages?u1=5uq9kDL9LQLjJLkNU2XLL8wAJmaA1IfFGykJuui9uEPYdMIoEbFqQpfSGsmuYFgj87R1bOTrb6gRXVMQclHlm7pm6Xny1EqWuwfa2ChzQv6lPnRwpg%3D%3D&u2=r4BYkJX2rwyblUcd&width=2560"
    ],
    colors: ["#d4af37", "#c0c0c0"],
    sizes: ["16″", "18″", "20″"],
    tags: ["luxury", "jewelry"]
  },
  {
    id: "p016",
    name: "Signet Statement Ring",
    category: "Jewelry",
    price: 6990,
    oldPrice: 9990,
    rating: 4.8,
    reviews: 64,
    stock: 11,
    description: "Hand-crafted signet ring with engraved detail. Bold, modern, unforgettable.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=RBk35%2B3mZU26wK%2BszYnwP9bDDLNDoFWLSnmkQfT6OTb1yn8GYRTcdL8YBqm%2FP1dkAY17LbN1i2QZ%2BcAAcAn%2FhOqDEjmlXpJSTqlVtIU5OBEKWeP3nArYyCOEzudh8UOmU%2FfV3klMh3muyOkTBgCNCNzA%2FKFlnI9HjlXjNU5PeeQzp92l&u2=jI7wxFxM7GUmgcRV&width=2560"
    ],
    colors: ["#d4af37", "#c0c0c0"],
    sizes: ["6", "7", "8", "9"],
    tags: ["jewelry"]
  },
  {
    id: "p017",
    name: "Layered Gold Chains Set",
    category: "Jewelry",
    price: 9500,
    oldPrice: 13500,
    rating: 4.8,
    reviews: 142,
    stock: 16,
    badge: "Bestseller",
    description: "Three perfectly-spaced layered chains. Effortless dimension, all day, every day.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=Ocuzfjg6gAD331ieln9hI8RfkpXJlo0cdDNwXPT%2FFPcNO8BCk5k1kbcKs4bzZQ5Uqu62GNuwk%2BZUF4KFo1hTy3iOYLqjLH3872RYSAhDzV6dio93%2Ff%2FNC2vf7O%2BLAlAWtVj%2BdUbio90uhuHzPVXaiSgvYk1ij%2FTWONT50MgkT%2B59YalE&u2=lWB669x9Hfc5%2FONd&width=2560"
    ],
    colors: ["#d4af37"],
    sizes: ["Standard"],
    tags: ["bestseller", "jewelry"]
  },
  {
    id: "p018",
    name: "Sunlit Gold Necklace Trio",
    category: "Jewelry",
    price: 11500,
    oldPrice: 14500,
    rating: 4.7,
    reviews: 53,
    stock: 7,
    description: "A trio of gold necklaces designed to be worn together — or apart. Versatile luxury.",
    images: [
      "https://sspark.genspark.ai/cfimages?u1=DSy3x9i89UM6alHCDu59tJYx%2FMnN%2FTb%2Fx06b2qn1DweGBPWXBukh7vR1KRkee2Eu2tQEjp%2F8jFxrOcA74Vwa4mwUeyqsjCtyZhj7LeYip9%2Fq5yAiE7heEtqLGxV0hUJLIxvgj%2FjhSlSFpHFCodoGln%2Bwu9sVoughow%2FuR5%2Bli0kt2rx9BxQLUscwG2k%2BM3s%2B0VP8fQ%3D%3D&u2=SZVg34jqovo8hZYY&width=2560"
    ],
    colors: ["#d4af37"],
    sizes: ["Set of 3"],
    tags: ["jewelry"]
  }
];

window.WH_CATEGORIES = [
  { id: "fashion", name: "Fashion", icon: "👗", count: 5,
    image: "https://sspark.genspark.ai/cfimages?u1=aahS9WR%2FodvrFh%2FZjenHtLXyA1ntwZYkjDR0dHp1I0iCjj8ZGIL0MgVRxTNCVIRoNnBEIgN2Tdag0IJiY7W0Ao7zfW4wi7vu96TD87us8IGvvIWXHNXQnlIdfmhylKpv&u2=3nX63Uerx0so2S3F&width=2560" },
  { id: "bags", name: "Bags", icon: "👜", count: 4,
    image: "https://sspark.genspark.ai/cfimages?u1=igHbXeM%2B68MZqyJsu2SPLJ2mQ3eY%2F1i4Cn6p6OickA5LU2oHaVdYvPjSxZQWiDI9BeoDf7oeo3FFvdGz8hEU99obltF2b2S93JUt%2FK3mbNR0gUmQXezu5WGS8H1hC1y0UGniE%2BTxZoOj%2FRdraXi5pEGLIDDGUZECUR6M&u2=BB48CaymAqt5OjEz&width=2560" },
  { id: "beauty", name: "Beauty", icon: "💄", count: 5,
    image: "https://sspark.genspark.ai/cfimages?u1=lDhPqxnUSWv%2FhuvamQ8KocbFjLNDTFW8GgOJND%2Bqpp1qRcsnHWIwbUA%2F8Ktqt1wJ71N1Celbpd13jSVGxP8tsRaDAA%3D%3D&u2=tnuBrt3xlnY2v1Zy&width=2560" },
  { id: "jewelry", name: "Jewelry", icon: "💍", count: 4,
    image: "https://sspark.genspark.ai/cfimages?u1=wNwV3ivsowGYVhxkcEeht2POkvd2e1bq2XDrmqK%2Ft4FQUQIhs4jPCDkXQy99qWTSfr9CZj7tsO11%2BpUori922SNFAgf3jT48FDwze95k3S2GFzjRCiF0V9waqWNq3KE0oAhf%2BUDL4MPPi2g%3D&u2=Y8FZBar2mLad2bJe&width=2560" }
];

window.WH_TESTIMONIALS = [
  { name: "Ayesha K.", city: "Karachi", rating: 5, text: "The quality is unbelievable for the price. My beige trench has become my signature piece. Delivery was lightning fast.", avatar: "AK" },
  { name: "Sara M.", city: "Lahore", rating: 5, text: "Women's Hub feels like a luxury boutique online. Packaging, fragrance, presentation — everything is premium.", avatar: "SM" },
  { name: "Hina R.", city: "Islamabad", rating: 5, text: "I ordered the rose-gold skincare set as a gift and it arrived like a treasure. My sister cried opening it ❤️", avatar: "HR" },
  { name: "Mariam J.", city: "Multan", rating: 4, text: "Beautiful jewelry, real photographs match the product. Will absolutely order again.", avatar: "MJ" }
];
