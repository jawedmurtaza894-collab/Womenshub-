/* ============================================================
   Women's Hub — Admin Dashboard JS
   ============================================================ */

// Auth guard — Firebase Auth if available, otherwise legacy localStorage admin
(function adminAuthGate() {
  const legacyOK = WH.state.user && WH.state.user.role === "admin";
  // Show a blocking login overlay until Firebase confirms an admin user
  function showLogin(msg) {
    if (document.getElementById("fbLoginOverlay")) return;
    const el = document.createElement("div");
    el.id = "fbLoginOverlay";
    el.style.cssText = "position:fixed;inset:0;background:#fdfaf6;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;font-family:Inter,sans-serif;";
    el.innerHTML = `
      <form id="fbLoginForm" style="max-width:380px;width:100%;background:#fff;padding:32px;border-radius:18px;box-shadow:0 20px 60px rgba(0,0,0,.08);border:1px solid #eee;">
        <h2 style="font-family:'Cormorant Garamond',serif;font-size:28px;margin:0 0 6px;">Admin Sign-in</h2>
        <p style="color:#888;font-size:13px;margin:0 0 20px;">${msg || "Women's Hub admin panel"}</p>
        <input id="fbEmail" type="email" placeholder="Email" required style="width:100%;padding:12px 14px;border:1px solid #e3dccb;border-radius:10px;margin-bottom:10px;font-size:14px;">
        <input id="fbPass"  type="password" placeholder="Password" required style="width:100%;padding:12px 14px;border:1px solid #e3dccb;border-radius:10px;margin-bottom:16px;font-size:14px;">
        <button type="submit" style="width:100%;padding:12px;background:linear-gradient(135deg,#c9a96a,#a8884a);color:#fff;border:0;border-radius:10px;font-weight:600;letter-spacing:.05em;cursor:pointer;">Sign In</button>
        <p id="fbErr" style="color:#c1554f;font-size:12px;margin:12px 0 0;min-height:16px;"></p>
      </form>`;
    document.body.appendChild(el);
    document.getElementById("fbLoginForm").onsubmit = async (e) => {
      e.preventDefault();
      const err = document.getElementById("fbErr"); err.textContent = "";
      try {
        await WH.fb.login(
          document.getElementById("fbEmail").value.trim(),
          document.getElementById("fbPass").value
        );
      } catch (ex) { err.textContent = ex.message || "Login failed"; }
    };
  }

  function waitFirebase(cb, tries = 0) {
    if (WH.fb && WH.fb.ready) return cb();
    if (WH.fb && WH.fb.configured === false) return cb(); // not configured → legacy mode
    if (tries > 50) return cb();
    setTimeout(() => waitFirebase(cb, tries + 1), 100);
  }

  waitFirebase(() => {
    if (WH.fb && WH.fb.ready) {
      WH.fb.onAuth((user) => {
        const allowed = user && (!window.WH_ADMIN_EMAIL || user.email === window.WH_ADMIN_EMAIL);
        if (allowed) {
          const o = document.getElementById("fbLoginOverlay"); if (o) o.remove();
        } else {
          showLogin(user ? "This account is not an admin." : "");
        }
      });
    } else if (!legacyOK) {
      alert("Admin access only. Login as admin first.");
      location.href = "../pages/login.html";
    }
  });
})();

const Admin = {
  charts: {},
  currentTab: "dashboard",
  editingProduct: null,
  pendingPaymentOrder: null,

  refresh() {
    WH.load();
    this.updateNotifBadge();
    if (typeof this.render === "function") this.render();
  },

  init() {
    document.querySelectorAll(".admin-nav a[data-tab]").forEach(a => {
      a.onclick = () => this.switchTab(a.dataset.tab);
    });
    document.getElementById("notifBell").onclick = (e) => {
      e.stopPropagation();
      const p = document.getElementById("notifPanel");
      p.classList.toggle("open");
      this.renderNotifPanel();
    };
    document.body.addEventListener("click", () => document.getElementById("notifPanel").classList.remove("open"));
    document.getElementById("notifPanel").addEventListener("click", e => e.stopPropagation());

    // initial render
    this.switchTab("dashboard");
    this.updateNotifBadge();

    // Real-time sync — listen for new orders from customer tabs
    window.addEventListener("storage", (e) => {
      if (e.key === "wh_sync" || e.key === "wh_orders" || e.key === "wh_notifications") {
        WH.load();
        this.updateNotifBadge();
        if (this.currentTab === "orders" || this.currentTab === "dashboard" || this.currentTab === "payments") this.render();
        // pulse + sound for new orders
        const latest = WH.state.notifications[0];
        if (latest && Date.now() - latest.createdAt < 5000 && latest.type === "order") {
          WH.playNotifSound();
          WH.toast(latest.title, latest.message, "success");
        }
      }
    });

    // Periodic recheck for demo (every 3s)
    setInterval(() => this.refresh(), 5000);
  },

  switchTab(tab) {
    this.currentTab = tab;
    document.querySelectorAll(".admin-nav a").forEach(a => a.classList.remove("active"));
    document.querySelector(`.admin-nav a[data-tab="${tab}"]`)?.classList.add("active");
    const titles = {
      dashboard: "Dashboard", orders: "Orders", payments: "Payment Verification",
      products: "Products", categories: "Categories", customers: "Customers",
      banners: "Banners", coupons: "Coupons", reviews: "Reviews",
      notifications: "Notifications", content: "Site Content"
    };
    document.getElementById("pageTitle").textContent = titles[tab] || tab;
    this.render();
  },

  render() {
    const c = document.getElementById("content");
    switch (this.currentTab) {
      case "dashboard": c.innerHTML = this.viewDashboard(); this.drawCharts(); break;
      case "orders": c.innerHTML = this.viewOrders(); break;
      case "payments": c.innerHTML = this.viewPayments(); break;
      case "products": c.innerHTML = this.viewProducts(); break;
      case "categories": c.innerHTML = this.viewCategories(); break;
      case "customers": c.innerHTML = this.viewCustomers(); break;
      case "banners": c.innerHTML = this.viewBanners(); break;
      case "coupons": c.innerHTML = this.viewCoupons(); break;
      case "reviews": c.innerHTML = this.viewReviews(); break;
      case "notifications": c.innerHTML = this.viewNotifications(); break;
      case "content": c.innerHTML = this.viewContent(); break;
    }
  },

  /* ============ DASHBOARD VIEW ============ */
  viewDashboard() {
    const orders = WH.state.orders;
    const revenue = orders.filter(o => o.paymentStatus !== "Rejected").reduce((s,o) => s + o.total, 0);
    const pendingCount = orders.filter(o => o.status === "Order Confirmed" || o.status === "Processing").length;
    const totalProducts = WH.state.products.length;
    const totalCustomers = JSON.parse(localStorage.getItem("wh_users")||"[]").length;
    const todayOrders = orders.filter(o => (Date.now() - o.createdAt) < 86400000).length;

    return `
      <div class="stat-grid">
        <div class="stat-card">
          <div class="sc-icon">💰</div>
          <div class="sc-label">Total Revenue</div>
          <div class="sc-value">${WH.fmt(revenue)}</div>
          <div class="sc-change">↑ From ${orders.length} orders</div>
        </div>
        <div class="stat-card green">
          <div class="sc-icon">📦</div>
          <div class="sc-label">Orders Today</div>
          <div class="sc-value">${todayOrders}</div>
          <div class="sc-change">${orders.length} total</div>
        </div>
        <div class="stat-card pink">
          <div class="sc-icon">⏳</div>
          <div class="sc-label">Pending Orders</div>
          <div class="sc-value">${pendingCount}</div>
          <div class="sc-change ${pendingCount>3?'down':''}">${pendingCount>3?'Action needed':'On track'}</div>
        </div>
        <div class="stat-card blue">
          <div class="sc-icon">👥</div>
          <div class="sc-label">Customers</div>
          <div class="sc-value">${totalCustomers}</div>
          <div class="sc-change">${totalProducts} products</div>
        </div>
      </div>

      <div class="chart-grid">
        <div class="chart-box">
          <h4>Revenue · Last 7 Days</h4>
          <canvas id="revenueChart" height="100"></canvas>
        </div>
        <div class="chart-box">
          <h4>Top Categories</h4>
          <canvas id="catChart" height="100"></canvas>
        </div>
      </div>

      <div class="admin-panel">
        <div class="panel-head">
          <h3>Recent Orders</h3>
          <a class="btn btn-outline btn-sm" onclick="Admin.switchTab('orders')">View All →</a>
        </div>
        <table class="admin-table">
          <thead><tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th><th>Date</th></tr></thead>
          <tbody>
            ${orders.slice(0,5).map(o => `
              <tr>
                <td><strong>${o.id}</strong></td>
                <td>${o.customer.name}<br><small style="color:var(--gray);">${o.customer.email}</small></td>
                <td><strong>${WH.fmt(o.total)}</strong></td>
                <td><span class="status-pill ${o.status.toLowerCase().replace(/ /g,'')}">${o.status}</span></td>
                <td><span class="status-pill ${o.paymentStatus.toLowerCase()}">${o.paymentStatus}</span></td>
                <td>${new Date(o.createdAt).toLocaleDateString()}</td>
              </tr>`).join("") || '<tr><td colspan="6" style="text-align:center;color:var(--gray);padding:30px;">No orders yet. Place a test order to see it appear here in real-time.</td></tr>'}
          </tbody>
        </table>
      </div>

      <div class="chart-grid">
        <div class="chart-box">
          <h4>Top-Selling Products</h4>
          <div id="topProducts"></div>
        </div>
        <div class="chart-box">
          <h4>Quick Actions</h4>
          <div style="display:flex;flex-direction:column;gap:10px;">
            <button class="btn btn-primary" onclick="Admin.openProductModal()">+ Add Product</button>
            <button class="btn btn-outline" onclick="Admin.switchTab('orders')">View Orders</button>
            <button class="btn btn-outline" onclick="Admin.switchTab('payments')">Verify Payments</button>
            <button class="btn btn-outline" onclick="Admin.switchTab('reviews')">Moderate Reviews</button>
          </div>
        </div>
      </div>`;
  },

  drawCharts() {
    // Revenue last 7 days
    const days = []; const revPerDay = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      days.push(d.toLocaleDateString('en-US', { weekday: 'short' }));
      const dayRev = WH.state.orders.filter(o => {
        const od = new Date(o.createdAt); return od.toDateString() === d.toDateString();
      }).reduce((s, o) => s + o.total, 0);
      revPerDay.push(dayRev);
    }
    if (this.charts.revenue) this.charts.revenue.destroy();
    const ctx = document.getElementById("revenueChart");
    if (ctx) {
      this.charts.revenue = new Chart(ctx, {
        type: "line",
        data: {
          labels: days,
          datasets: [{
            label: "Revenue", data: revPerDay,
            borderColor: "#c9a96a", backgroundColor: "rgba(201,169,106,.12)",
            tension: .35, fill: true, borderWidth: 3, pointRadius: 5,
            pointBackgroundColor: "#c9a96a"
          }]
        },
        options: { plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} }
      });
    }

    // Category chart
    const catData = {};
    WH.state.products.forEach(p => catData[p.category] = (catData[p.category]||0) + 1);
    if (this.charts.cat) this.charts.cat.destroy();
    const ctxC = document.getElementById("catChart");
    if (ctxC) {
      this.charts.cat = new Chart(ctxC, {
        type: "doughnut",
        data: { labels: Object.keys(catData), datasets:[{ data: Object.values(catData),
          backgroundColor: ["#c9a96a","#e8a5a5","#a8884a","#d8c4a3","#4a8a5a"] }] },
        options: { plugins:{legend:{position:"bottom"}}, cutout:"60%" }
      });
    }

    // Top products
    const topEl = document.getElementById("topProducts");
    if (topEl) {
      const top = [...WH.state.products].sort((a,b)=>b.reviews-a.reviews).slice(0,4);
      topEl.innerHTML = top.map((p,i) => `
        <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--gray-line);">
          <span style="font-family:var(--font-display);font-size:20px;color:var(--gold-deep);width:24px;">${i+1}.</span>
          <img src="${p.images[0]}" style="width:44px;height:54px;object-fit:cover;border-radius:6px;">
          <div style="flex:1;"><strong style="font-size:13px;">${p.name}</strong><br><small style="color:var(--gray);">${p.reviews} reviews · ${p.rating}★</small></div>
          <strong>${WH.fmt(p.price)}</strong>
        </div>`).join("");
    }
  },

  /* ============ ORDERS ============ */
  viewOrders() {
    const orders = WH.state.orders;
    return `
      <div class="admin-panel">
        <div class="panel-head">
          <h3>All Orders (${orders.length})</h3>
          <div class="right">
            <select onchange="Admin.filterOrders(this.value)" style="padding:8px 14px;border-radius:100px;border:1px solid var(--gray-line);background:var(--bg-card);font-size:13px;color:var(--black);">
              <option value="all">All Status</option>
              <option>Order Confirmed</option><option>Processing</option><option>Packed</option><option>Shipped</option><option>Out for Delivery</option><option>Delivered</option>
            </select>
          </div>
        </div>
        <table class="admin-table">
          <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Update</th></tr></thead>
          <tbody id="ordersTBody">${this.ordersRows(orders)}</tbody>
        </table>
      </div>`;
  },
  ordersRows(list) {
    if (!list.length) return '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--gray);">No orders.<br><small>Place a test order from the storefront — it will appear here in real-time with a sound notification.</small></td></tr>';
    return list.map(o => `
      <tr>
        <td><strong>${o.id}</strong><br><small style="color:var(--gray);">${new Date(o.createdAt).toLocaleString()}</small></td>
        <td>${o.customer.name}<br><small style="color:var(--gray);">${o.customer.phone}</small></td>
        <td><strong>${WH.fmt(o.total)}</strong><br><small style="color:var(--gray);">${o.items.length} item(s)</small></td>
        <td>${o.paymentMethod.toUpperCase()}<br><span class="status-pill ${o.paymentStatus.toLowerCase()}">${o.paymentStatus}</span></td>
        <td><span class="status-pill ${o.status.toLowerCase().replace(/ /g,'')}">${o.status}</span></td>
        <td>
          <select onchange="Admin.changeStatus('${o.id}', this.value)" style="padding:6px 10px;font-size:12px;border-radius:6px;border:1px solid var(--gray-line);background:var(--bg-card);color:var(--black);">
            <option>${o.status}</option>
            <option>Order Confirmed</option><option>Processing</option><option>Packed</option>
            <option>Shipped</option><option>Out for Delivery</option><option>Delivered</option>
          </select>
          <button class="btn-icon-sm" onclick="Admin.viewOrderDetails('${o.id}')" title="View">👁</button>
        </td>
      </tr>`).join("");
  },
  filterOrders(status) {
    const list = status === "all" ? WH.state.orders : WH.state.orders.filter(o => o.status === status);
    document.getElementById("ordersTBody").innerHTML = this.ordersRows(list);
  },
  changeStatus(id, status) {
    const note = prompt("Optional tracking note for customer:");
    WH.updateOrderStatus(id, status, note || "");
    WH.toast("Status updated", `Order ${id} → ${status}`, "success");
    this.render();
  },
  viewOrderDetails(id) {
    const o = WH.state.orders.find(x => x.id === id); if (!o) return;
    alert(`Order ${o.id}\n\nCustomer: ${o.customer.name}\nEmail: ${o.customer.email}\nPhone: ${o.customer.phone}\nAddress: ${o.customer.address}, ${o.customer.city}\n\nItems:\n${o.items.map(i => `  - ${i.name} × ${i.qty}`).join("\n")}\n\nTotal: ${WH.fmt(o.total)}\nPayment: ${o.paymentMethod} (${o.paymentStatus})\nStatus: ${o.status}`);
  },

  /* ============ PAYMENTS ============ */
  viewPayments() {
    const pending = WH.state.orders.filter(o => o.paymentMethod === "easypaisa");
    return `
      <div class="admin-panel">
        <div class="panel-head">
          <h3>EasyPaisa Payment Verifications</h3>
          <small style="color:var(--gray);">Verify customer payment screenshots</small>
        </div>
        ${pending.length ? '' : '<p style="text-align:center;padding:40px;color:var(--gray);">No EasyPaisa payments to review.</p>'}
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;">
          ${pending.map(o => `
            <div style="background:var(--bg-soft);border:1px solid var(--gray-line);border-radius:14px;padding:18px;">
              <div style="display:flex;justify-content:space-between;margin-bottom:10px;">
                <strong>${o.id}</strong>
                <span class="status-pill ${o.paymentStatus.toLowerCase()}">${o.paymentStatus}</span>
              </div>
              <div style="font-size:13px;color:var(--gray);margin-bottom:10px;">
                ${o.customer.name} · ${o.customer.phone}<br>
                Amount: <strong style="color:var(--black);">${WH.fmt(o.total)}</strong>
              </div>
              ${o.screenshot ? `<img src="${o.screenshot}" style="width:100%;border-radius:10px;cursor:pointer;max-height:200px;object-fit:cover;" onclick="Admin.openScreenshot('${o.id}')">` : '<div style="padding:30px;text-align:center;background:var(--bg-card);border-radius:10px;color:var(--gray);">No screenshot uploaded</div>'}
              ${o.paymentStatus === "Pending" ? `<div style="display:flex;gap:8px;margin-top:12px;">
                <button class="btn btn-primary btn-sm" style="flex:1;" onclick="Admin.verifyPay('${o.id}','Verified')">✓ Verify</button>
                <button class="btn btn-outline btn-sm" style="flex:1;border-color:var(--danger);color:var(--danger);" onclick="Admin.verifyPay('${o.id}','Rejected')">✕ Reject</button>
              </div>` : ''}
            </div>`).join("")}
        </div>
      </div>`;
  },
  openScreenshot(orderId) {
    const o = WH.state.orders.find(x => x.id === orderId); if (!o || !o.screenshot) return;
    this.pendingPaymentOrder = orderId;
    document.getElementById("screenshotImg").src = o.screenshot;
    document.getElementById("verifyBtn").onclick = () => { this.verifyPay(orderId, "Verified"); closeModal('screenshotModal'); };
    document.getElementById("rejectBtn").onclick = () => { this.verifyPay(orderId, "Rejected"); closeModal('screenshotModal'); };
    document.getElementById("screenshotModal").classList.add("open");
  },
  verifyPay(orderId, status) {
    WH.verifyPayment(orderId, status);
    WH.toast(`Payment ${status}`, `Order ${orderId}`, status === "Verified" ? "success" : "danger");
    this.render();
  },

  /* ============ PRODUCTS ============ */
  viewProducts() {
    return `
      <div class="admin-panel">
        <div class="panel-head">
          <h3>Products (${WH.state.products.length})</h3>
          <div class="right">
            <input placeholder="Search..." oninput="Admin.searchProducts(this.value)" style="padding:8px 14px;border-radius:100px;border:1px solid var(--gray-line);background:var(--bg-card);font-size:13px;color:var(--black);">
            <button class="btn btn-primary btn-sm" onclick="Admin.openProductModal()">+ Add Product</button>
          </div>
        </div>
        <table class="admin-table">
          <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Actions</th></tr></thead>
          <tbody id="productsTBody">${this.productsRows(WH.state.products)}</tbody>
        </table>
      </div>`;
  },
  productsRows(list) {
    return list.map(p => `
      <tr>
        <td>
          <div class="prod-cell">
            <img src="${p.images[0]}">
            <div><strong>${p.name}</strong><br><small>${p.id}</small></div>
          </div>
        </td>
        <td>${p.category}</td>
        <td><strong>${WH.fmt(p.price)}</strong>${p.oldPrice?`<br><small style="text-decoration:line-through;color:var(--gray);">${WH.fmt(p.oldPrice)}</small>`:""}</td>
        <td>${p.stock <= 5 ? `<span style="color:var(--danger);font-weight:600;">${p.stock}</span>` : p.stock}</td>
        <td>${p.rating}★ <small style="color:var(--gray);">(${p.reviews})</small></td>
        <td>
          <button class="btn-icon-sm" onclick="Admin.editProduct('${p.id}')">✎</button>
          <button class="btn-icon-sm danger" onclick="Admin.deleteProduct('${p.id}')">🗑</button>
        </td>
      </tr>`).join("");
  },
  searchProducts(q) {
    const list = WH.state.products.filter(p => p.name.toLowerCase().includes(q.toLowerCase()) || p.category.toLowerCase().includes(q.toLowerCase()));
    document.getElementById("productsTBody").innerHTML = this.productsRows(list);
  },
  openProductModal(productId = null) {
    this.editingProduct = productId;
    document.getElementById("modalTitle").textContent = productId ? "Edit Product" : "Add Product";
    const fields = ["pmName","pmCategory","pmStock","pmPrice","pmOldPrice","pmDesc","pmImage","pmColors","pmSizes","pmBadge"];
    fields.forEach(f => document.getElementById(f).value = "");
    if (productId) {
      const p = WH.findProduct(productId); if (!p) return;
      document.getElementById("pmName").value = p.name;
      document.getElementById("pmCategory").value = p.category;
      document.getElementById("pmStock").value = p.stock;
      document.getElementById("pmPrice").value = p.price;
      document.getElementById("pmOldPrice").value = p.oldPrice || "";
      document.getElementById("pmDesc").value = p.description;
      document.getElementById("pmImage").value = p.images[0];
      document.getElementById("pmColors").value = (p.colors||[]).join(", ");
      document.getElementById("pmSizes").value = (p.sizes||[]).join(", ");
      document.getElementById("pmBadge").value = p.badge || "";
    }
    document.getElementById("productModal").classList.add("open");
  },
  editProduct(id) { this.openProductModal(id); },
  async deleteProduct(id) {
    if (!confirm("Delete this product?")) return;
    if (WH.fb && WH.fb.ready) {
      try { await WH.fb.deleteProduct(id); }
      catch (e) { return WH.toast("Delete failed", e.message, "danger"); }
    } else {
      WH.state.products = WH.state.products.filter(p => p.id !== id);
      WH.save("products");
    }
    WH.toast("Product deleted", "", "danger");
    this.render();
  },

  /* ============ CATEGORIES ============ */
  viewCategories() {
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>Categories</h3></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;">
          ${WH_CATEGORIES.map(c => `
            <div style="background:var(--bg-soft);border-radius:14px;overflow:hidden;border:1px solid var(--gray-line);">
              <img src="${c.image}" style="width:100%;height:160px;object-fit:cover;">
              <div style="padding:14px;">
                <strong>${c.icon} ${c.name}</strong><br>
                <small style="color:var(--gray);">${WH.state.products.filter(p => p.category === c.name).length} products</small>
              </div>
            </div>`).join("")}
        </div>
      </div>`;
  },

  /* ============ CUSTOMERS ============ */
  viewCustomers() {
    const users = JSON.parse(localStorage.getItem("wh_users")||"[]");
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>Customers (${users.length})</h3></div>
        <table class="admin-table">
          <thead><tr><th>Customer</th><th>Email</th><th>Joined</th><th>Orders</th><th>Spent</th></tr></thead>
          <tbody>
            ${users.length ? users.map(u => {
              const userOrders = WH.state.orders.filter(o => o.customer.email === u.email);
              const spent = userOrders.reduce((s,o) => s + o.total, 0);
              return `<tr>
                <td><div class="prod-cell" style="gap:10px;">
                  <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#c9a96a,#a8884a);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;">${u.name[0]}</div>
                  <div><strong>${u.name}</strong></div>
                </div></td>
                <td>${u.email}</td>
                <td>${new Date(u.createdAt).toLocaleDateString()}</td>
                <td>${userOrders.length}</td>
                <td><strong>${WH.fmt(spent)}</strong></td>
              </tr>`;
            }).join("") : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--gray);">No customers yet. Customers will appear here after they register.</td></tr>'}
          </tbody>
        </table>
      </div>`;
  },

  /* ============ BANNERS ============ */
  viewBanners() {
    const banners = JSON.parse(localStorage.getItem("wh_banners") || '[{"title":"Summer Edit","subtitle":"The Desert Collection","active":true},{"title":"Beauty","subtitle":"Rose Gold Ritual","active":true},{"title":"Jewelry","subtitle":"Heirloom Gold","active":true}]');
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>Banners</h3><button class="btn btn-primary btn-sm" onclick="WH.toast('Demo','Banner upload form would open here')">+ Add Banner</button></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
          ${banners.map(b => `
            <div style="background:linear-gradient(135deg,#d8c4a3,#e8a5a5);color:#fff;border-radius:14px;padding:30px;min-height:180px;display:flex;flex-direction:column;justify-content:space-between;">
              <small style="opacity:.85;">${b.title}</small>
              <strong style="font-family:var(--font-display);font-size:24px;">${b.subtitle}</strong>
              <div style="display:flex;gap:8px;">
                <button class="btn-icon-sm" style="background:rgba(255,255,255,.25);color:#fff;">✎</button>
                <button class="btn-icon-sm" style="background:rgba(255,255,255,.25);color:#fff;">${b.active?"●":"○"}</button>
              </div>
            </div>`).join("")}
        </div>
      </div>`;
  },

  /* ============ COUPONS ============ */
  viewCoupons() {
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>Discount Coupons</h3><button class="btn btn-primary btn-sm" onclick="WH.toast('Demo','Coupon creation form would open here')">+ New Coupon</button></div>
        <table class="admin-table">
          <thead><tr><th>Code</th><th>Discount</th><th>Min Order</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            <tr><td><strong>LUXE10</strong></td><td>10%</td><td>None</td><td><span class="status-pill verified">Active</span></td><td><button class="btn-icon-sm">✎</button></td></tr>
            <tr><td><strong>PREMIUM20</strong></td><td>20%</td><td>${WH.fmt(10000)}</td><td><span class="status-pill verified">Active</span></td><td><button class="btn-icon-sm">✎</button></td></tr>
            <tr><td><strong>WELCOME500</strong></td><td>${WH.fmt(500)}</td><td>${WH.fmt(2000)}</td><td><span class="status-pill verified">Active</span></td><td><button class="btn-icon-sm">✎</button></td></tr>
          </tbody>
        </table>
      </div>`;
  },

  /* ============ REVIEWS ============ */
  viewReviews() {
    const reviews = WH.state.reviews;
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>Reviews (${reviews.length})</h3></div>
        ${reviews.length ? reviews.map(r => {
          const p = WH.findProduct(r.productId);
          return `<div style="background:var(--bg-soft);border-radius:12px;padding:18px;margin-bottom:10px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
              <div><strong>${r.userName}</strong> · <small>${p?.name||""}</small><br><span style="color:var(--gold);">${"★".repeat(r.rating)}${"☆".repeat(5-r.rating)}</span></div>
              <span class="status-pill ${r.status === 'approved' ? 'verified' : r.status === 'rejected' ? 'rejected' : 'pending'}">${r.status}</span>
            </div>
            <p style="color:var(--gray);font-size:14px;">${r.text}</p>
            ${r.status === "pending" ? `<div style="display:flex;gap:8px;margin-top:10px;">
              <button class="btn btn-primary btn-sm" onclick="Admin.moderateReview('${r.id}','approved')">✓ Approve</button>
              <button class="btn btn-outline btn-sm" style="border-color:var(--danger);color:var(--danger);" onclick="Admin.moderateReview('${r.id}','rejected')">✕ Reject</button>
            </div>` : ""}
          </div>`;
        }).join("") : '<p style="text-align:center;padding:40px;color:var(--gray);">No reviews yet.</p>'}
      </div>`;
  },
  moderateReview(id, status) {
    const r = WH.state.reviews.find(x => x.id === id); if (!r) return;
    r.status = status;
    WH.save("reviews");
    WH.toast("Review " + status, "", status === "approved" ? "success" : "danger");
    this.render();
  },

  /* ============ NOTIFICATIONS ============ */
  viewNotifications() {
    const n = WH.state.notifications;
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>All Notifications (${n.length})</h3>
          <button class="btn btn-outline btn-sm" onclick="WH.state.notifications=[];WH.save('notifications');Admin.render();Admin.updateNotifBadge();">Clear All</button>
          <button class="btn btn-primary btn-sm" onclick="Admin.sendBroadcast()">+ Send Broadcast</button>
        </div>
        ${n.length ? n.map(notif => `
          <div style="background:var(--bg-soft);border-radius:12px;padding:16px 18px;margin-bottom:8px;border-left:3px solid var(--gold);">
            <strong>${notif.title}</strong><br>
            <small style="color:var(--gray);">${notif.message} · ${new Date(notif.createdAt).toLocaleString()}</small>
          </div>`).join("") : '<p style="text-align:center;padding:40px;color:var(--gray);">No notifications.</p>'}
      </div>`;
  },
  sendBroadcast() {
    const msg = prompt("Broadcast message to all customers:");
    if (!msg) return;
    WH.pushNotification({ type: "broadcast", title: "📣 Announcement", message: msg, sound: true });
    WH.toast("Broadcast sent", "", "success");
    this.render();
  },

  /* ============ CONTENT ============ */
  viewContent() {
    return `
      <div class="admin-panel">
        <div class="panel-head"><h3>Site Content</h3></div>
        <div class="field"><label>Site Title</label><input value="Women's Hub — Luxury Curated for Her"></div>
        <div class="field"><label>Hero Headline</label><input value="Luxury, her way."></div>
        <div class="field"><label>Hero Subheadline</label><textarea rows="2">From hand-finished gold jewelry to limited-run beauty edits — every piece in our hub is selected for one woman: you.</textarea></div>
        <div class="field"><label>WhatsApp Number</label><input value="${WH.WHATSAPP}"></div>
        <div class="field"><label>EasyPaisa Number</label><input value="${WH.EASYPAISA}"></div>
        <div class="field"><label>Support Email</label><input value="support@womenshub.com"></div>
        <button class="btn btn-primary" onclick="WH.toast('Saved','Site content updated','success')">Save Changes</button>
      </div>`;
  },

  /* ============ NOTIF BELL ============ */
  updateNotifBadge() {
    const unread = WH.state.notifications.filter(n => !n.read).length;
    const dot = document.getElementById("notifDot");
    if (dot) dot.style.display = unread > 0 ? "block" : "none";
    const badge = document.getElementById("newOrdersBadge");
    const newOrders = WH.state.orders.filter(o => o.status === "Order Confirmed").length;
    if (badge) {
      badge.style.display = newOrders > 0 ? "inline-block" : "none";
      badge.textContent = newOrders;
    }
  },
  renderNotifPanel() {
    const p = document.getElementById("notifPanel");
    const list = WH.state.notifications.slice(0, 10);
    p.innerHTML = `<h4>🔔 Notifications</h4>` +
      (list.length ? list.map(n => `
        <div class="notif-item" onclick="${n.orderId ? `Admin.switchTab('orders');document.getElementById('notifPanel').classList.remove('open')` : ''}">
          <strong>${n.title}</strong>
          <small>${n.message}</small><br>
          <small style="opacity:.6;">${this.timeAgo(n.createdAt)}</small>
        </div>`).join("") : '<div style="padding:20px;text-align:center;color:var(--gray);font-size:13px;">No notifications.</div>');
    // mark read
    WH.state.notifications.forEach(n => n.read = true);
    WH.save("notifications");
    this.updateNotifBadge();
  },
  timeAgo(ts) {
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 60) return s + "s ago";
    if (s < 3600) return Math.floor(s/60) + "m ago";
    if (s < 86400) return Math.floor(s/3600) + "h ago";
    return Math.floor(s/86400) + "d ago";
  }
};

/* ============ Global helpers ============ */
function closeModal(id) { document.getElementById(id).classList.remove("open"); }
function logout() {
  if (WH.fb && WH.fb.ready) { WH.fb.logout().then(() => location.reload()); }
  else { WH.logout(); }
}

async function saveProduct() {
  const btnLabel = "Saving…";
  const fileInput = document.getElementById("pmImageFile");
  let imageUrl = document.getElementById("pmImage").value.trim();

  // Upload selected file to Firebase Storage (if any)
  if (fileInput && fileInput.files && fileInput.files[0]) {
    if (!(WH.fb && WH.fb.ready)) return WH.toast("Firebase not ready", "Cannot upload image", "danger");
    try {
      WH.toast("Uploading", "Image to Firebase Storage…", "info");
      imageUrl = await WH.fb.uploadImage(fileInput.files[0]);
    } catch (e) { return WH.toast("Upload failed", e.message, "danger"); }
  }

  const p = {
    id: Admin.editingProduct || null,
    name: document.getElementById("pmName").value.trim(),
    category: document.getElementById("pmCategory").value,
    stock: +document.getElementById("pmStock").value || 0,
    price: +document.getElementById("pmPrice").value || 0,
    oldPrice: +document.getElementById("pmOldPrice").value || 0,
    description: document.getElementById("pmDesc").value.trim(),
    images: [imageUrl || "https://via.placeholder.com/600x800"],
    colors: document.getElementById("pmColors").value.split(",").map(s => s.trim()).filter(Boolean),
    sizes: document.getElementById("pmSizes").value.split(",").map(s => s.trim()).filter(Boolean),
    badge: document.getElementById("pmBadge").value.trim(),
    rating: 4.5, reviews: 0, tags: []
  };
  if (!p.name || !p.price) return WH.toast("Invalid", "Name & price required", "danger");

  if (WH.fb && WH.fb.ready) {
    try { await WH.fb.saveProduct(p); }
    catch (e) { return WH.toast("Save failed", e.message, "danger"); }
  } else {
    // localStorage fallback
    if (!p.id) p.id = "p" + Date.now();
    if (Admin.editingProduct) {
      const idx = WH.state.products.findIndex(x => x.id === Admin.editingProduct);
      if (idx >= 0) WH.state.products[idx] = { ...WH.state.products[idx], ...p };
    } else {
      WH.state.products.unshift(p);
    }
    WH.save("products");
  }

  WH.toast("Saved", Admin.editingProduct ? "Product updated" : "Product added", "success");
  closeModal("productModal");
  Admin.editingProduct = null;
  if (fileInput) fileInput.value = "";
  Admin.render();
}

window.Admin = Admin;
window.AdminDashboard = Admin;
document.addEventListener("DOMContentLoaded", () => Admin.init());
