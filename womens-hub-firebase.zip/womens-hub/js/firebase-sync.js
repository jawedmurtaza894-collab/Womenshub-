/* ============================================================
   Women's Hub — Firebase Sync Layer
   ------------------------------------------------------------
   • Loads Firebase SDK dynamically (no HTML edits required)
   • Subscribes to Firestore `products` collection in real-time
   • Pushes changes into WH.state.products and re-renders the page
   • Exposes WH.fb.{saveProduct, deleteProduct, uploadImage,
                   login, logout, onAuth}
   • Falls back to localStorage if Firebase config is missing
     so the site keeps working before setup.
   ============================================================ */
(function () {
  const cfg = window.WH_FIREBASE_CONFIG;
  const configured = cfg && cfg.apiKey && !cfg.apiKey.includes("PASTE");
  WH.fb = { ready: false, configured };

  if (!configured) {
    console.warn("[WH] Firebase not configured yet — using localStorage. Edit js/firebase-config.js to enable cloud sync.");
    return;
  }

  // ---------- Dynamic SDK loader ----------
  const V = "10.12.2";
  const base = `https://www.gstatic.com/firebasejs/${V}`;
  const scripts = [
    `${base}/firebase-app-compat.js`,
    `${base}/firebase-auth-compat.js`,
    `${base}/firebase-firestore-compat.js`,
    `${base}/firebase-storage-compat.js`,
  ];

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src; s.onload = resolve; s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  (async function init() {
    try {
      for (const src of scripts) await loadScript(src);

      firebase.initializeApp(cfg);
      const db      = firebase.firestore();
      const auth    = firebase.auth();
      const storage = firebase.storage();

      WH.fb.db = db; WH.fb.auth = auth; WH.fb.storage = storage;
      WH.fb.ready = true;

      // ---------- Real-time product sync ----------
      db.collection("products").orderBy("createdAt", "desc").onSnapshot(
        (snap) => {
          const products = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          if (products.length === 0 && Array.isArray(window.WH_PRODUCTS)) {
            // Empty Firestore? Keep sample data visible.
            WH.state.products = window.WH_PRODUCTS;
          } else {
            WH.state.products = products;
          }
          localStorage.setItem("wh_products", JSON.stringify(WH.state.products));
          // Notify pages so they can re-render
          window.dispatchEvent(new CustomEvent("wh:products-updated"));
        },
        (err) => console.error("[WH] Firestore sync error:", err)
      );

      // ---------- CRUD helpers ----------
      WH.fb.saveProduct = async (p) => {
        const data = { ...p, updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
        if (!data.createdAt) data.createdAt = firebase.firestore.FieldValue.serverTimestamp();
        const id = p.id;
        delete data.id;
        if (id) {
          await db.collection("products").doc(id).set(data, { merge: true });
          return id;
        } else {
          const ref = await db.collection("products").add(data);
          return ref.id;
        }
      };

      WH.fb.deleteProduct = async (id) => {
        await db.collection("products").doc(id).delete();
      };

      WH.fb.uploadImage = async (file) => {
        const path = `products/${Date.now()}_${file.name.replace(/\s+/g, "_")}`;
        const ref  = storage.ref().child(path);
        await ref.put(file);
        return await ref.getDownloadURL();
      };

      // ---------- Auth helpers ----------
      WH.fb.login   = (email, pass) => auth.signInWithEmailAndPassword(email, pass);
      WH.fb.logout  = () => auth.signOut();
      WH.fb.onAuth  = (cb) => auth.onAuthStateChanged(cb);

      window.dispatchEvent(new Event("wh:firebase-ready"));
    } catch (err) {
      console.error("[WH] Firebase init failed:", err);
    }
  })();
})();
