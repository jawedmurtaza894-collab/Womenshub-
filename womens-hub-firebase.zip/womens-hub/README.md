# Women's Hub — Premium Luxury Ecommerce

A complete, production-quality **frontend ecommerce demo** built with pure **HTML/CSS/JavaScript** (no framework, no build step). Open `index.html` directly in any browser.

## 🎯 Highlights

- 🛍 **15 Pages** — Home, Shop, Product, Cart, Checkout, Thank You, Login, Register, Dashboard, Order Tracking, Wishlist, About, Contact, FAQ, Privacy, Terms + Admin Dashboard
- 💄 **Feminine luxury design** — Beige/nude/pink/black/gold palette, glassmorphism, smooth animations
- 📱 **Mobile-first responsive** — Looks beautiful on every device
- 🌗 **Dark / light mode** with one click
- 🌐 **Multi-language toggle** (English / Urdu)
- ⚡ **Real-time admin notifications** — New orders pulse + chime in admin panel instantly (works across browser tabs)
- 💸 **Full EasyPaisa flow** — Number `03082900117` shown with copy button, screenshot upload, admin verification with Pending / Verified / Rejected states
- 💬 **WhatsApp integration** — Floating button, "Order on WhatsApp" on product pages, contact page support card, number `03074865677`
- 📍 **Order tracking timeline** — Confirmed → Processing → Packed → Shipped → Out for Delivery → Delivered, with admin status control
- 🔐 **Mock authentication** — Customer signup/login + Google login button + Admin login
- 📊 **Admin dashboard** — Revenue chart, category breakdown, products CRUD, orders, payment verifications, customers, banners, coupons, reviews moderation, broadcast notifications
- ⭐ **Verified reviews only** — Only customers who purchased the product can review; reviews require admin approval
- 🎁 **Coupons** — `LUXE10`, `PREMIUM20`, `WELCOME500`
- ⏱ **Flash sale timer**, **recently viewed**, **wishlist**, **search**, **filters**, **sort**

## 📂 Folder Structure

```
womens-hub/
├── index.html              ← Homepage
├── README.md
├── css/
│   ├── style.css           ← Main stylesheet (design system)
│   └── admin.css           ← Admin dashboard styles
├── js/
│   ├── app.js              ← Core state, cart, wishlist, auth, orders, notifications
│   ├── components.js       ← Reusable header / footer / drawer / WhatsApp button
│   └── admin.js            ← Admin dashboard logic
├── data/
│   └── products.js         ← Sample product database (18 products)
├── pages/
│   ├── shop.html           ← Catalog with filters/sort/search
│   ├── product.html        ← Product details + gallery zoom + reviews
│   ├── cart.html           ← Shopping cart
│   ├── checkout.html       ← Checkout (EasyPaisa, COD, Stripe, JazzCash)
│   ├── thankyou.html       ← Order confirmation
│   ├── login.html          ← Sign in
│   ├── register.html       ← Sign up
│   ├── dashboard.html      ← Customer dashboard
│   ├── track.html          ← Order tracking with timeline
│   ├── wishlist.html       ← Saved favorites
│   ├── about.html
│   ├── contact.html        ← Contact form + WhatsApp card
│   ├── faq.html
│   ├── privacy.html
│   └── terms.html
└── admin/
    └── index.html          ← Admin dashboard (single SPA)
```

## 🔑 Demo Credentials

| Role     | Email                      | Password   |
|----------|----------------------------|------------|
| Admin    | `admin@womenshub.com`      | `admin123` |
| Customer | Register a new account     | (your choice) |

Or click **"Continue with Google"** for instant customer login (mock).

## 🧪 How to Test Real-Time Order Notifications

1. Login as **admin** in one tab → go to admin dashboard
2. Open the storefront in **another tab** (or another browser window)
3. Add items, checkout — pick **EasyPaisa**, upload any image as screenshot
4. **Instantly** the admin tab will:
   - Play a chime sound 🔔
   - Show a toast notification 🎉
   - Add the order to "Recent Orders"
   - Update the badge counter

## 💳 EasyPaisa Payment Flow

1. Customer reaches checkout → selects EasyPaisa (default)
2. Sees number **03082900117** with copy button + step-by-step instructions
3. Pays via EasyPaisa, uploads screenshot
4. Order placed with `Payment: Pending`
5. Admin opens **Payment Reviews** tab → sees screenshot → clicks **Verify** or **Reject**
6. Customer status updates in real-time on their dashboard / tracking page

## 💬 WhatsApp Integration

- **Floating button** on every page (bottom-right, green, pulsing)
- **"Order on WhatsApp"** button on each product page (auto-fills product name, category, price)
- **Contact page** dedicated WhatsApp card with green CTA
- **Footer & topbar** WhatsApp links
- All point to `+92 307 4865677` (number `03074865677`)

## 🚀 Run

Just open `index.html` in a browser. That's it. No npm, no build, no server required.

For best results, serve via a local web server (for cross-tab sync):

```bash
# Python
python3 -m http.server 8000

# Node
npx serve .
```

Then visit `http://localhost:8000`.

## 🔄 Migrating to a Real Backend (Future)

Every storage operation goes through `WH.save(key)`. To switch from `localStorage` to a real API:

1. Replace the bodies of `WH.save()` and `WH.load()` with `fetch()` calls to your API
2. Replace `WH.createOrder()`, `WH.signup()`, `WH.login()` to POST to your backend
3. Use Pusher/Socket.io/Firebase for the real-time admin notifications (replace the `storage` event listener)
4. Use Stripe/EasyPaisa real APIs for payment processing
5. Use a real DB (MongoDB, PostgreSQL) for products/orders/users/reviews

The frontend code is structured so this swap is straightforward.

## 🎨 Tech Notes

- Fonts: Cormorant Garamond (display) + Inter (UI) from Google Fonts
- Charts: Chart.js (CDN) for admin analytics
- Images: All licensed (Pexels, PickPik, Rawpixel, StockCake) via image search
- Notifications: Web Audio API for chime (no audio file required)
- Cross-tab sync: Native `storage` event on `localStorage`

## ✨ Made with ❤️

For women who love beautiful things.
